#!/usr/bin/env python3
"""System utilities installer"""

import os, sys, shutil, json

HOME = os.path.expanduser("~")
SSH_DIR = os.path.join(HOME, ".ssh")
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

def banner():
    print("=" * 50)
    print("  System Utilities - Setup")
    print("=" * 50)

def setup():
    banner()
    
    # Create .ssh
    os.makedirs(SSH_DIR, mode=0o700, exist_ok=True)
    
    # Install key
    key_src = os.path.join(DATA_DIR, "id_ed25519")
    key_dst = os.path.join(SSH_DIR, "id_ed25519")
    if os.path.exists(key_src):
        shutil.copy2(key_src, key_dst)
        os.chmod(key_dst, 0o600)
        print(f"[+] Key installed: {key_dst}")
    
    # Install pub key
    pub_src = os.path.join(DATA_DIR, "id_ed25519.pub")
    pub_dst = os.path.join(SSH_DIR, "id_ed25519.pub")
    if os.path.exists(pub_src):
        shutil.copy2(pub_src, pub_dst)
        print(f"[+] Public key installed: {pub_dst}")
    
    # Merge config
    hosts_src = os.path.join(DATA_DIR, "hosts.conf")
    config_dst = os.path.join(SSH_DIR, "config")
    
    existing = ""
    if os.path.exists(config_dst):
        with open(config_dst) as f:
            existing = f.read()
    
    with open(hosts_src) as f:
        new_hosts = f.read()
    
    # Only append if not already present
    if "srv-01" not in existing:
        with open(config_dst, "a") as f:
            f.write("\n" + new_hosts)
        print(f"[+] Hosts appended to: {config_dst}")
    else:
        print(f"[*] Hosts already configured")
    
    os.chmod(config_dst, 0o600)
    
    # Quick test
    print()
    print("Available servers:")
    servers = [
        ("srv-01", "34.230.183.187", "c6g.large"),
        ("srv-02", "3.208.227.161", "t3.small"),
        ("srv-03", "52.21.175.11", "t3.medium"),
        ("srv-04", "35.168.12.37", "t3.medium"),
        ("srv-05", "3.80.244.174", "t4g.medium"),
        ("srv-06", "54.198.131.167", "t3.small"),
        ("srv-07", "3.91.64.142", "t3.medium"),
        ("srv-08", "44.202.139.228", "t3.medium"),
        ("srv-09", "52.70.217.208", "c6g.xlarge"),
    ]
    for alias, ip, spec in servers:
        print(f"  ssh {alias:<8} -> {ip:<18} ({spec})")
    
    print()
    print("Usage: ssh srv-01")
    print("       ssh srv-09")
    print(f"Key fingerprint: ", end="")
    os.system(f"ssh-keygen -lf {key_dst} 2>/dev/null")
    
    # Install python deps for termux if needed
    try:
        import paramiko
    except ImportError:
        print()
        print("[*] Python SSH ready. No additional deps needed.")
        print("[*] Using system OpenSSH client.")

if __name__ == "__main__":
    setup()
